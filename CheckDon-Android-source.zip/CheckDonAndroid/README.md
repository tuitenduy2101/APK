# Check Đơn (Android) v2

Giao diện mới (Jetpack Compose, Material 3, tự đổi màu theo hình nền Android 12+ và chế độ tối).
Tra mã vận đơn **SPX Express**, **J&T**, **GHN**.

## Tính năng
- Nhập list: mỗi dòng `mã, sđt, ghi chú` (SPX chỉ cần mã; J&T và GHN cần thêm sđt). Tự nhận diện ĐVVC.
- **Lấy data**: tra cả danh sách, nghỉ giữa các request theo **Delay** (mặc định 1000 ms, chỉnh 0–10000 ms, bước 50).
- **Check lại (N)**: chỉ tra lại các đơn đang lỗi. Có thể bật **tự động check lại** 1–5 vòng.
- Lọc theo trạng thái (Thành công / Đang đi / Hoàn / Lỗi), xem hành trình từng đơn, copy mã/tình trạng.
- Dữ liệu tự lưu, mở lại app vẫn còn.

## Build APK (không cần cài Android Studio)
1. Tạo repo GitHub, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Tab **Actions** → **Build APK** → chờ khoảng 5–8 phút.
3. Tải artifact **CheckDon-apk** → `app-debug.apk` → chép vào điện thoại và cài
   (cần bật "Cài ứng dụng từ nguồn không rõ").

Nếu có Android Studio: mở thư mục này, bấm Run.
