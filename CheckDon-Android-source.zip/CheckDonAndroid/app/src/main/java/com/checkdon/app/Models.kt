package com.checkdon.app

import java.util.UUID

enum class Carrier(val label: String, val needsPhone: Boolean) {
    SPX("SPX Express", false), JT("J&T", true), GHN("GHN", true);

    companion object {
        /** Nhận diện ĐVVC theo độ dài/định dạng mã (giống app gốc) */
        fun detect(code: String): Carrier? {
            val n = code.length
            val digits = code.all { it in '0'..'9' }
            return when {
                n in 14..20 -> SPX
                n in 10..13 && digits -> JT
                n in 6..9 -> GHN
                else -> null
            }
        }
    }
}

enum class CheckState { IDLE, LOADING, OK, ERROR }

enum class Category(val label: String) {
    PENDING("Chưa tra"), SHIPPING("Đang đi"), DONE("Thành công"), RETURNED("Hoàn/Trả"), ERROR("Lỗi")
}

data class TrackEvent(val time: String, val text: String)

data class Order(
    val id: String = UUID.randomUUID().toString(),
    val code: String,
    val phone: String = "",
    val note: String = "",
    val carrier: Carrier,
    val status: String = "",
    val lastTime: String = "",
    val state: CheckState = CheckState.IDLE,
    val error: String = "",
    val history: List<TrackEvent> = emptyList(),
) {
    fun category(): Category = when (state) {
        CheckState.ERROR -> Category.ERROR
        CheckState.IDLE, CheckState.LOADING -> Category.PENDING
        CheckState.OK -> {
            val s = status.lowercase()
            when {
                "hoàn" in s || "trả" in s || "thất bại" in s -> Category.RETURNED
                "thành công" in s || "đã giao" in s || "ký nhận" in s -> Category.DONE
                else -> Category.SHIPPING
            }
        }
    }
}

data class TrackResult(val status: String, val time: String, val history: List<TrackEvent>)
