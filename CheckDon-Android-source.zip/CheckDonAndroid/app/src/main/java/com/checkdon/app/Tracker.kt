package com.checkdon.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class TrackException(msg: String) : Exception(msg)

object Tracker {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"

    private val vn = TimeZone.getTimeZone("Asia/Ho_Chi_Minh")
    private fun fmt(ms: Long): String =
        SimpleDateFormat("dd/MM HH:mm", Locale.US).apply { timeZone = vn }.format(Date(ms))

    suspend fun track(o: Order): TrackResult = withContext(Dispatchers.IO) {
        when (o.carrier) {
            Carrier.SPX -> spx(o.code)
            Carrier.JT -> { need(o); jt(o.code, o.phone) }
            Carrier.GHN -> { need(o); ghn(o.code, o.phone) }
        }
    }

    private fun need(o: Order) { if (o.phone.isBlank()) throw TrackException("Thiếu số điện thoại") }

    private fun call(req: Request): String {
        val r = req.newBuilder()
            .header("User-Agent", UA)
            .header("Accept-Language", "vi,en-GB;q=0.9,en;q=0.8")
            .build()
        client.newCall(r).execute().use { resp ->
            if (!resp.isSuccessful) throw TrackException("Lỗi HTTP ${resp.code}")
            return resp.body?.string() ?: ""
        }
    }

    private fun done(events: List<TrackEvent>): TrackResult {
        val first = events.firstOrNull() ?: throw TrackException("Không có dữ liệu / mã sai")
        return TrackResult(first.text, first.time, events)
    }

    // ---- SPX Express ----
    private fun spx(code: String): TrackResult {
        val url = "https://spx.vn/shipment/order/open/order/get_order_info?spx_tn=" +
            java.net.URLEncoder.encode(code, "UTF-8") + "&language_code=vi"
        val recs: JSONArray = JSONObject(call(Request.Builder().url(url).build()))
            .optJSONObject("data")?.optJSONObject("sls_tracking_info")?.optJSONArray("records")
            ?: throw TrackException("Không có dữ liệu / mã sai")
        val list = (0 until recs.length()).map { recs.getJSONObject(it) }
            .sortedByDescending { it.optLong("actual_time") }
            .map {
                val ts = it.optLong("actual_time")
                TrackEvent(if (ts > 0) fmt(ts * 1000) else "", it.optString("buyer_description"))
            }
        return done(list)
    }

    // ---- J&T Express (HTML) ----
    private fun jt(code: String, phone: String): TrackResult {
        val url = okhttp3.HttpUrl.Builder().scheme("https").host("jtexpress.vn")
            .addPathSegments("vi/tracking")
            .addQueryParameter("type", "track")
            .addQueryParameter("billcode", code)
            .addQueryParameter("cellphone", phone).build()
        val html = call(Request.Builder().url(url).build())
        val events = Jsoup.parse(html).select("div.result-vandon-item").map { item ->
            val time = item.selectFirst("ion-icon[name=time-outline] ~ span")?.text().orEmpty()
            val date = item.selectFirst("ion-icon[name=calendar-clear-outline] ~ span")?.text().orEmpty()
            val text = item.children().filter { it.tagName() == "div" }.getOrNull(1)?.text().orEmpty()
            TrackEvent("$time $date".trim(), text)
        }
        return done(events)
    }

    // ---- Giao Hàng Nhanh ----
    private fun ghn(code: String, phone: String): TrackResult {
        val body = JSONObject().put("order_code", code).put("phone_verify", phone).toString()
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder()
            .url("https://fe-online-gateway.ghn.vn/order-tracking/public-api/client/tracking-logs")
            .post(body)
            .header("Accept", "application/json")
            .header("Origin", "https://donhang.ghn.vn")
            .header("Referer", "https://donhang.ghn.vn/")
            .build()
        val logs = JSONObject(call(req)).optJSONObject("data")?.optJSONArray("tracking_logs")
            ?: throw TrackException("Không có dữ liệu / mã sai")
        val utc = TimeZone.getTimeZone("UTC")
        val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = utc }
        val items = (0 until logs.length()).map { logs.getJSONObject(it) }.map { l ->
            val raw = l.optString("action_at")
            val ms = runCatching { parser.parse(raw.take(19))!!.time }.getOrDefault(0L)
            val status = l.optString("status_name")
            val addr = l.optJSONObject("location")?.optString("address").orEmpty()
            ms to TrackEvent(if (ms > 0) fmt(ms) else raw, listOf(status, addr).filter { it.isNotBlank() }.joinToString(" - "))
        }.sortedByDescending { it.first }.map { it.second }
        return done(items)
    }
}
