@file:OptIn(ExperimentalMaterial3Api::class)

package com.checkdon.app

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private fun Category.color(): Color = when (this) {
    Category.DONE -> Color(0xFF2E7D32)
    Category.SHIPPING -> Color(0xFF1565C0)
    Category.RETURNED -> Color(0xFF6A1B9A)
    Category.ERROR -> Color(0xFFC62828)
    Category.PENDING -> Color(0xFF757575)
}

@Composable
fun CheckDonApp(vm: OrderViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf<Category?>(null) }

    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    fun copy(s: String) {
        clip.setText(AnnotatedString(s))
        scope.launch { snack.currentSnackbarData?.dismiss(); snack.showSnackbar("Đã copy!") }
    }

    val shown = vm.orders.filter { filter == null || it.category() == filter }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Check Đơn", fontWeight = FontWeight.Bold)
                        Text("Delay ${vm.delayMs} ms" + if (vm.autoRetry > 0) " · tự thử lại ${vm.autoRetry} vòng" else "",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Set delay") }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Thêm") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Copy danh sách") }, onClick = { menuOpen = false; copy(vm.exportText()) })
                            DropdownMenuItem(text = { Text("Xoá sạch") }, onClick = { menuOpen = false; confirmClear = true })
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showAdd = true }, icon = { Icon(Icons.Default.Add, null) }, text = { Text("Thêm mã") })
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.navigationBarsPadding()) {
                    if (vm.running) {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text("Đang kiểm tra… ${vm.progress}", Modifier.padding(start = 16.dp, top = 6.dp), style = MaterialTheme.typography.labelMedium)
                    }
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (vm.running) {
                            Button(onClick = { vm.cancel() }, Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                                Icon(Icons.Default.Close, null); Spacer(Modifier.width(6.dp)); Text("Dừng")
                            }
                        } else {
                            Button(onClick = { vm.checkAll() }, Modifier.weight(1f), enabled = vm.orders.isNotEmpty()) {
                                Icon(Icons.Default.Search, null); Spacer(Modifier.width(6.dp)); Text("Lấy data")
                            }
                            FilledTonalButton(onClick = { vm.retryFailed() }, Modifier.weight(1f), enabled = vm.failedCount > 0) {
                                Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Check lại (${vm.failedCount})")
                            }
                        }
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            // bộ lọc theo trạng thái
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("Tất cả ${vm.orders.size}") })
                Category.values().forEach { c ->
                    val n = vm.orders.count { it.category() == c }
                    if (n > 0) FilterChip(
                        selected = filter == c, onClick = { filter = if (filter == c) null else c },
                        label = { Text("${c.label} $n") },
                        leadingIcon = { Box(Modifier.size(10.dp).clip(CircleShape).background(c.color())) },
                    )
                }
            }
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (vm.orders.isEmpty()) "Chưa có mã vận đơn.\nBấm “Thêm mã” để nhập danh sách." else "Không có đơn nào trong mục này.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(shown, key = { it.id }) { o ->
                        OrderCard(o, onClick = { selectedId = o.id }, onRecheck = { vm.check(o.id) }, onDelete = { vm.remove(o.id) }, enabled = !vm.running)
                    }
                }
            }
        }
    }

    if (showAdd) AddSheet(vm) { showAdd = false }
    if (showSettings) SettingsDialog(vm) { showSettings = false }
    selectedId?.let { id ->
        vm.orders.firstOrNull { it.id == id }?.let { o ->
            DetailSheet(o, onCopy = ::copy, onRecheck = { vm.check(o.id) }, canRecheck = !vm.running) { selectedId = null }
        }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Xoá toàn bộ danh sách?") },
        confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false }) { Text("Xoá sạch") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Huỷ") } },
    )
}

@Composable
private fun OrderCard(o: Order, onClick: () -> Unit, onRecheck: () -> Unit, onDelete: () -> Unit, enabled: Boolean) {
    val accent = o.category().color()
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f).compositeOver(MaterialTheme.colorScheme.surface)),
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(accent))
            Column(Modifier.weight(1f).padding(start = 12.dp, top = 10.dp, bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(o.code, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    AssistChip(onClick = onClick, label = { Text(o.carrier.label, style = MaterialTheme.typography.labelSmall) }, modifier = Modifier.height(24.dp))
                }
                if (o.phone.isNotBlank()) Text("SĐT: ${o.phone}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                when (o.state) {
                    CheckState.LOADING -> Text("Đang kiểm tra…", style = MaterialTheme.typography.bodyMedium)
                    CheckState.ERROR -> Text("⚠ ${o.error}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                    CheckState.OK -> {
                        Text(o.status, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                        if (o.lastTime.isNotBlank()) Text(o.lastTime, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    CheckState.IDLE -> {}
                }
                if (o.note.isNotBlank()) Text("📝 ${o.note}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column {
                IconButton(onClick = onRecheck, enabled = enabled) { Icon(Icons.Default.Refresh, "Check lại") }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Xoá") }
            }
        }
    }
}

@Composable
private fun AddSheet(vm: OrderViewModel, onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    val clip = LocalClipboardManager.current
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp).navigationBarsPadding().imePadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Nhập danh sách mã vận đơn", style = MaterialTheme.typography.titleMedium)
            Text("Mỗi dòng 1 đơn: mã, sđt, ghi chú\nSPX chỉ cần mã • J&T và GHN cần thêm số điện thoại",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
                placeholder = { Text("SPXVN0123456789, 0912345678, khách A") })
            if (info.isNotEmpty()) Text(info, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { clip.getText()?.text?.let { text += (if (text.isEmpty()) "" else "\n") + it } }) { Text("Dán") }
                Button(modifier = Modifier.weight(1f), enabled = text.isNotBlank(), onClick = {
                    val (a, s) = vm.add(text)
                    if (s == 0) onClose() else { info = "Đã thêm $a, bỏ qua $s (sai mã/trùng)"; text = "" }
                }) { Text("Thêm mã") }
            }
        }
    }
}

@Composable
private fun SettingsDialog(vm: OrderViewModel, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Cài đặt tra cứu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Delay giữa 2 lần tra: ${vm.delayMs} ms", fontWeight = FontWeight.Medium)
                Slider(value = vm.delayMs.toFloat(), onValueChange = { vm.updateDelay((it / 50).toInt() * 50) }, valueRange = 0f..3000f, steps = 59)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0, 300, 500, 1000, 1500).forEach { v ->
                        FilterChip(selected = vm.delayMs == v, onClick = { vm.updateDelay(v) }, label = { Text("$v") })
                    }
                }
                Text("Mạng tốt: 300–1000 ms hoặc 0. Bị lỗi nhiều (tra quá nhanh) thì tăng lên.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text(if (vm.autoRetry == 0) "Tự động check lại đơn lỗi: Tắt" else "Tự động check lại đơn lỗi: ${vm.autoRetry} vòng", fontWeight = FontWeight.Medium)
                Slider(value = vm.autoRetry.toFloat(), onValueChange = { vm.updateAutoRetry(it.toInt()) }, valueRange = 0f..5f, steps = 4)
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Xong") } },
    )
}

@Composable
private fun DetailSheet(o: Order, onCopy: (String) -> Unit, onRecheck: () -> Unit, canRecheck: Boolean, onClose: () -> Unit) {
    val accent = o.category().color()
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(o.code, style = MaterialTheme.typography.titleLarge, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Text("${o.carrier.label}" + (if (o.phone.isNotBlank()) " · ${o.phone}" else "") + (if (o.note.isNotBlank()) " · ${o.note}" else ""),
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (o.state == CheckState.ERROR) Text("⚠ ${o.error}", color = MaterialTheme.colorScheme.error)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onCopy(o.code) }) { Text("Copy mã") }
                OutlinedButton(onClick = { onCopy(o.status) }, enabled = o.status.isNotBlank()) { Text("Copy tình trạng") }
                FilledTonalButton(onClick = onRecheck, enabled = canRecheck) { Text("Check lại") }
            }
            Spacer(Modifier.height(6.dp))
            Text("Hành trình", style = MaterialTheme.typography.titleMedium)
            if (o.history.isEmpty()) Text("Chưa có dữ liệu", color = MaterialTheme.colorScheme.onSurfaceVariant)
            o.history.forEachIndexed { i, e ->
                Row(Modifier.height(IntrinsicSize.Min)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(20.dp)) {
                        Box(Modifier.padding(top = 5.dp).size(10.dp).clip(CircleShape).background(if (i == 0) accent else MaterialTheme.colorScheme.outline))
                        if (i < o.history.lastIndex) Box(Modifier.width(2.dp).weight(1f).background(MaterialTheme.colorScheme.outlineVariant))
                    }
                    Column(Modifier.padding(start = 8.dp, bottom = 12.dp)) {
                        Text(e.time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(e.text, fontWeight = if (i == 0) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}
