package com.checkdon.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class OrderViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("checkdon", Context.MODE_PRIVATE)

    val orders = mutableStateListOf<Order>()

    /** Thời gian nghỉ giữa 2 request (ms) */
    var delayMs by mutableIntStateOf(prefs.getInt("DelayTime", 1000)); private set
    /** Số vòng tự động check lại đơn lỗi sau khi chạy xong */
    var autoRetry by mutableIntStateOf(prefs.getInt("AutoRetry", 0)); private set
    var running by mutableStateOf(false); private set
    var progress by mutableStateOf(""); private set

    private var job: Job? = null

    init { load() }

    val failedCount get() = orders.count { it.state == CheckState.ERROR }

    fun updateDelay(v: Int) { delayMs = v.coerceIn(0, 10000); prefs.edit().putInt("DelayTime", delayMs).apply() }
    fun updateAutoRetry(v: Int) { autoRetry = v.coerceIn(0, 5); prefs.edit().putInt("AutoRetry", autoRetry).apply() }

    // ---------- nhập dữ liệu ----------
    /** Mỗi dòng: mã, sđt, ghi chú (ngăn cách bằng , ; tab hoặc khoảng trắng). Trả về (đã thêm, bỏ qua) */
    fun add(text: String): Pair<Int, Int> {
        var added = 0; var skipped = 0
        for (line in text.lines()) {
            var parts = line.split(',', ';', '\t').map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size == 1) parts = parts[0].split(Regex("\\s+")).filter { it.isNotEmpty() }
            val code = parts.firstOrNull()?.uppercase() ?: continue
            val carrier = Carrier.detect(code)
            if (carrier == null || orders.any { it.code == code }) { skipped++; continue }
            val rest = parts.drop(1)
            val phone = rest.firstOrNull { p -> p.length >= 4 && p.all { it.isDigit() } } ?: ""
            val note = rest.filter { it != phone }.joinToString(" ")
            orders.add(Order(code = code, phone = phone, note = note, carrier = carrier))
            added++
        }
        save()
        return added to skipped
    }

    fun remove(id: String) { orders.removeAll { it.id == id }; save() }
    fun clearAll() { cancel(); orders.clear(); save() }
    fun exportText() = orders.joinToString("\n") { "${it.code}\t${it.phone}\t${it.status}\t${it.note}" }

    // ---------- kiểm tra ----------
    fun checkAll() = run(orders.map { it.id })
    /** Check lại riêng các đơn đang bị lỗi */
    fun retryFailed() = run(orders.filter { it.state == CheckState.ERROR }.map { it.id })
    fun check(id: String) = run(listOf(id))
    fun cancel() { job?.cancel() }

    private fun run(ids: List<String>) {
        if (running || ids.isEmpty()) return
        running = true
        job = viewModelScope.launch {
            try {
                var pending = ids
                var round = 0
                while (pending.isNotEmpty()) {
                    pending.forEachIndexed { n, id ->
                        progress = (if (round == 0) "" else "Thử lại #$round · ") + "${n + 1}/${pending.size}"
                        checkOne(id)
                        if (n < pending.size - 1 && delayMs > 0) delay(delayMs.toLong())
                    }
                    save()
                    if (round >= autoRetry) break
                    pending = orders.filter { it.state == CheckState.ERROR }.map { it.id }
                    round++
                    if (pending.isNotEmpty()) delay(maxOf(delayMs, 500).toLong())
                }
            } finally {
                for (i in orders.indices) if (orders[i].state == CheckState.LOADING) orders[i] = orders[i].copy(state = CheckState.IDLE)
                running = false
                progress = ""
                save()
            }
        }
    }

    private fun idx(id: String) = orders.indexOfFirst { it.id == id }

    private suspend fun checkOne(id: String) {
        var i = idx(id).takeIf { it >= 0 } ?: return
        orders[i] = orders[i].copy(state = CheckState.LOADING)
        val snapshot = orders[i]
        try {
            val r = Tracker.track(snapshot)
            i = idx(id).takeIf { it >= 0 } ?: return
            orders[i] = orders[i].copy(status = r.status, lastTime = r.time, history = r.history, state = CheckState.OK, error = "")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            i = idx(id).takeIf { it >= 0 } ?: return
            orders[i] = orders[i].copy(state = CheckState.ERROR, error = e.message ?: "Lỗi mạng")
        }
    }

    // ---------- lưu / đọc ----------
    private fun save() {
        val arr = JSONArray()
        orders.forEach { o ->
            arr.put(JSONObject()
                .put("id", o.id).put("code", o.code).put("phone", o.phone).put("note", o.note)
                .put("carrier", o.carrier.name).put("status", o.status).put("lastTime", o.lastTime)
                .put("state", o.state.name).put("error", o.error)
                .put("history", JSONArray().also { h ->
                    o.history.forEach { e -> h.put(JSONObject().put("t", e.time).put("x", e.text)) }
                }))
        }
        prefs.edit().putString("orders", arr.toString()).apply()
    }

    private fun load() {
        val s = prefs.getString("orders", null) ?: return
        runCatching {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                val h = j.optJSONArray("history") ?: JSONArray()
                val st = CheckState.valueOf(j.getString("state"))
                orders.add(Order(
                    id = j.getString("id"), code = j.getString("code"), phone = j.optString("phone"),
                    note = j.optString("note"), carrier = Carrier.valueOf(j.getString("carrier")),
                    status = j.optString("status"), lastTime = j.optString("lastTime"),
                    state = if (st == CheckState.LOADING) CheckState.IDLE else st, error = j.optString("error"),
                    history = (0 until h.length()).map { TrackEvent(h.getJSONObject(it).optString("t"), h.getJSONObject(it).optString("x")) },
                ))
            }
        }
    }
}
